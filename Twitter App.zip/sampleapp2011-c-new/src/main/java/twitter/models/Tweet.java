package twitter.models;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Tweet {
     public String id , user , content , time,username;
    public String getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public String getContent() {
        return content;
    }

    public String getTime() {
        return time;
    }

    public String getUsername() {
        return username;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public static final RowMapper<Tweet> rowMapper = new RowMapper<Tweet>() {
        @Override public Tweet mapRow(ResultSet resultSet, int i) throws SQLException {
            return new Tweet(resultSet);
        }
    };
    public Tweet() {}

    public Tweet(ResultSet rs){
        try{
            this.content=rs.getString("content");
            this.user = rs.getString("userid");
            this.time = rs.getString("time");
            this.id = rs.getString("tweetid");
            this.username = rs.getString("username");
        }
        catch (Exception exc){}
    }


}
