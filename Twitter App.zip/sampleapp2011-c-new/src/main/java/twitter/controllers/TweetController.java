package twitter.controllers;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import twitter.models.Tweet;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpSession;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

@Controller
@RequestMapping("/tweet")
public class TweetController {
    SimpleJdbcTemplate jdbc;
    Utility util;
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;

    @Autowired
    public TweetController(SimpleJdbcTemplate jdb, Utility uti, UserStore ust, TweetStore tst, FollowStore fst) {
        this.jdbc = jdb;
        this.followstore = fst;
        this.util = uti;
        this.userstore = ust;
        this.tweetstore = tst;
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    Hashtable<String, String> addTweet(@RequestParam String name, HttpSession session) {
        Gson gson = new Gson();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        Tweet temptweet = new Tweet();
        temptweet.content = name;
        temptweet.user = (String) session.getAttribute("userid");
        temptweet.time = dateFormat.format(date);
        tweetstore.tweet(temptweet);
        Hashtable<String, String> hs = new Hashtable<String, String>();
        temptweet.username = (String) session.getAttribute("username");
        hs.put("val", gson.toJson(temptweet));
        return hs;
    }

    @RequestMapping(value = "/user")
    @ResponseBody
    Hashtable<String, String> getTweets(@RequestParam String userid, @RequestParam Integer offset, @RequestParam Integer size) {
        Hashtable<String, String> hs = new Hashtable<String, String>();
        Gson gson = new Gson();
        List<Tweet> ls = userstore.getUserTweets(userid, offset, size);
        hs.put("val", gson.toJson(ls));
        return hs;
    }


    @RequestMapping(value = "/retweet", method = RequestMethod.POST)
    @ResponseBody
    Tweet reTweet(@RequestParam Integer id, HttpSession session) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        tweetstore.retweet((String) session.getAttribute("userid"), id, dateFormat.format(date));
        return null;
    }

    @RequestMapping(value = "/countnew")
    @ResponseBody
    int getcountnewtweet(HttpSession session, @RequestParam String time) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        return tweetstore.getcountnewtweets((String) session.getAttribute("userid"), time);
    }

    @RequestMapping(value = "/getnew")
    @ResponseBody
    List<Tweet> getnewtweet(HttpSession session, @RequestParam String time) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        return tweetstore.getnewtweets((String) session.getAttribute("userid"), time);
    }

}
