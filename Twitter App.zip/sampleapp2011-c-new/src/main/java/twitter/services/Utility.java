package twitter.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Service;
import twitter.models.UploadImage;

import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;

@Service
public class Utility {
        SimpleJdbcTemplate jdbc;
        private String path_prefix = "src/main/webapp/static/Timages/";

    @Autowired
    public Utility(SimpleJdbcTemplate jdb){
        this.jdbc = jdb;
    }

    public String genkey(){
        return jdbc.queryForObject("select uuid()",String.class);
    }

    public String doHash(String val){
        return jdbc.queryForObject("select md5(?)",String.class,val);
    }

    public String SHAhash(Object obj){
        byte[] bytes = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            oos.close();
            bos.close();
            bytes = bos.toByteArray ();
        }
        catch (IOException ex) {
            //TODO: Handle the exception
        }
        MessageDigest md;
        String str;
        byte[] byteData;
        try{
            md = MessageDigest.getInstance("SHA-256");
            md.update(bytes);
            byteData=md.digest();

        StringBuffer hexString = new StringBuffer();
        for (int i=0;i<byteData.length;i++) {
            String hex=Integer.toHexString(0xff & byteData[i]);
            if(hex.length()==1) hexString.append('0');
            hexString.append(hex);
        }
            str = hexString.toString();
        }
        catch (Exception exc){str = new String("Exception thrown");}
        return str;
    }

    public boolean StoreImage(UploadImage img){
        String path = path_prefix;
        //System.out.println("whatever");
        try{
            File profile = new File(path+"profile"+img.getName());
            File thumb = new File(path+"thumb"+img.getName());
           // System.out.print("hellohellohello"+thumb);
            //img.getFileData().transferTo(file);
            img.compress();
            ImageIO.write(img.profile,"jpg",profile);
            ImageIO.write(img.thumbnail,"jpg",thumb);
            return true;

        }
        catch (Exception exc){return false;}


    }
}
