package twitter.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created with IntelliJ IDEA.
 * User: vinayak
 * Date: 20/7/12
 * Time: 3:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class Authorizer extends HandlerInterceptorAdapter {
    private final ThreadLocal<String> userid;

    @Autowired
    public Authorizer(@Qualifier("userID") ThreadLocal<String> userID){
        this.userid=userID;

    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
        if(request.getRequestURI().contains("restapi")|| request.getRequestURI().equals("/") || (request.getRequestURI().equals("/user/login")&&request.getMethod()=="POST") || request.getRequestURI().equals("/user/signup"))
            return true;
        HttpSession session = request.getSession(false);
        if (session != null) {
            String userName = (String) session.getAttribute("username");
            if (userName != null) {
                userid.set((String) session.getAttribute("userID"));
               // response.sendRedirect("/hello");
                return true;
            }
        }
       //response.sendRedirect("/hello");
       //return false;
        response.sendRedirect("/");
        return  false;
    }
}
