package twitter.models;

import org.imgscalr.Scalr;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class UploadImage {
    private String name;
    private CommonsMultipartFile fileData;
    public BufferedImage profile;
    public BufferedImage thumbnail;
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public CommonsMultipartFile getFileData()
    {
        return fileData;
    }

    public void setFileData(CommonsMultipartFile fileData)
    {
        this.fileData = fileData;
    }

    public void compress(){
        try{
        InputStream in = new ByteArrayInputStream(fileData.getBytes());
        BufferedImage image = ImageIO.read(in);
        profile=Scalr.resize(image,88,100);
        thumbnail=Scalr.resize(image,40,40);
        }
        catch (Exception exc){}
    }
}
