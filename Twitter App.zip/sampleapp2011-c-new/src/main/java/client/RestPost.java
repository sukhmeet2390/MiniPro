package client;

import org.springframework.beans.factory.annotation.Autowired;
import twitter.services.Utility;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Scanner;

public class RestPost {
    static Utility util;

    // | Sukhmeet | s@s.com |
    //d8578edf8458ce06fbc5bb76a58c5ca4 |
      //      9252b475-e1e4-11e1-96d2-f0def1e96fbe |
    // http://localhost:8080/RESTfulExample/json/product/post
    @Autowired
    public RestPost(Utility uti){
        this.util=uti;
    }

    public static String SHAhash(Object obj){
        byte[] bytes = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            oos.close();
            bos.close();
            bytes = bos.toByteArray ();
        }
        catch (IOException ex) {
            //TODO: Handle the exception
        }
        MessageDigest md;
        String str;
        byte[] byteData;
        try{
            md = MessageDigest.getInstance("SHA-256");
            md.update(bytes);
            byteData=md.digest();

            StringBuffer hexString = new StringBuffer();
            for (int i=0;i<byteData.length;i++) {
                String hex=Integer.toHexString(0xff & byteData[i]);
                if(hex.length()==1) hexString.append('0');
                hexString.append(hex);
            }
            str = hexString.toString();
        }
        catch (Exception exc){str = new String("Exception thrown");}
        return str;
    }
    public static void main(String[] args) {
        String urls ,method,input,userid;
        String password = "test";
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the URL");
        //urls = "http://localhost:8080/restapi/tweets/users/e6126bdd-e075-11e1-8478-f0def1e96f28";//in.nextLine();
        urls = in.nextLine();
        System.out.println("Enter the method type");
        method = in.nextLine();
        method = method.toUpperCase();
        System.out.println("Enter the input body");
        input = in.nextLine();
        System.out.println("Ener the password");
        password = in.nextLine();
        userid = "e6126bdd-e075-11e1-8478-f0def1e96f28";//in.nextLine();


        try {

            // URL url = new URL(
            //       "http://localhost:8080/restapi/users");
            URL url = new URL(urls);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            //conn.setRequestMethod("POST");
            conn.setRequestMethod(method);
            if(method.equals("GET"))
                conn.setRequestProperty("Accept","application/json");
            else{
            conn.setRequestProperty("Content-Type", "application/json");

              //eb4d4cda-dd6f-11e1-8478-f0def1e96f28
            //String input ="{\"uname\":\"newresttestclient\",\"uemail\":\"xyz\",\"pass\":\"test\"}"+"test";
            String input2 = input + password;
            if(method.equals("DELETE"))
                conn.setRequestProperty("hash",SHAhash(password));
            else
                conn.setRequestProperty("hash",SHAhash(input2));
            //conn.setRequestProperty("userid","e6126bdd-e075-11e1-8478-f0def1e96f28");
            //conn.setRequestProperty("userid",userid);
            //input ="{\"uname\":\"newresttestclient\",\"uemail\":\"xyz\",\"pass\":\"test\"}";
            if(!method.equals("DELETE")){
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();
            }
            }

            if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {

                System.out.println(output);
            }

            conn.disconnect();

        } catch (MalformedURLException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }}}