package twitter.controllers;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import twitter.models.User;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * User: sukhmeet.s
 * Date: 8/16/12
 * Time: 6:42 PM
 * To change this template use File | Settings | File Templates.
 */
@Controller
public class DefaultController {
    SimpleJdbcTemplate jdbc;
    Utility util;
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;

    @Autowired
    public DefaultController(SimpleJdbcTemplate jdb, Utility uti, UserStore ust, TweetStore tst, FollowStore fst) {
        this.jdbc = jdb;
        this.followstore = fst;
        this.util = uti;
        this.userstore = ust;
        this.tweetstore = tst;
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    ModelAndView homepageget(HttpSession session, HttpServletRequest request) {
        if (session.getAttribute("userid") != null)
            return new ModelAndView("redirect:/user/feed");
        else {
            String msg = request.getParameter("login");
            ModelAndView mv = new ModelAndView("index");
            if (msg != null)
                mv.addObject("msg", msg);
            return mv;
        }

    }

    @RequestMapping(value = "/search")
    ModelAndView Search(@RequestParam String query) {
        ModelAndView mv = new ModelAndView("search");
        Gson gson = new Gson();
        //System.out.println(gson.toJson(tweetstore.searchTweet(query)) + "\n" + gson.toJson(userstore.SearchUser(query)));
        mv.addObject("tweets", tweetstore.searchTweet(query));
        mv.addObject("users", userstore.SearchUser(query));
        return mv;
    }
    @RequestMapping(value = "/getallusers")
    @ResponseBody
        List<User> getAllUsers() {
        return userstore.getAllUsers();
    }


}
