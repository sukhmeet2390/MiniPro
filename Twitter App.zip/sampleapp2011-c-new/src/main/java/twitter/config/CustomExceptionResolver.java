package twitter.config;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class CustomExceptionResolver implements HandlerExceptionResolver {
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object o, Exception e) {
        //System.out.println("Image upload ERROR");

        if (e instanceof MaxUploadSizeExceededException) {
           // System.out.print("finally is it??");
            request.getSession().setAttribute("error", "Image Size more than 1 mb");
            return new ModelAndView("redirect:/user/editProfile");
        }
        else {
            ModelAndView mv =  new ModelAndView("error");
            mv.addObject("exception",e.getClass().getName());
            return mv;
        }//To change body of implemented methods use File | Settings | File Templates.
    }
}