package twitter.models;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Follower {
    public String id,userA,userB, time_unfollow;
    public static final RowMapper<Follower> rowMapper = new RowMapper<Follower>() {
        @Override public Follower mapRow(ResultSet resultSet, int i) throws SQLException {
            return new Follower(resultSet);
        }
    };
    public Follower() {}

    public Follower(ResultSet rs){

    }
}
