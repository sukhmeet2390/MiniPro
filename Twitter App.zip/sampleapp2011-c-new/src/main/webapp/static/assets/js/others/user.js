function addTweet(form) {
    $.post('/tweet/add', $(form).serialize(), function(data) {
        var obj = $.parseJSON(data.val);
        obj['userid'] = obj.user;
        obj["displayTime"] = correctTime(obj.time);
        var html = $(new EJS({url:'/static/ejs/addTweet.ejs'}).render(obj));
        $('.feed-content').prepend(html);
        oldTweetTime = $('.tweet-container').children()[0].children[3].value;
        $('#feed-content div:first').slideDown("slow");
        document.getElementById('edit-name').value = "";
        document.getElementById('countdown').innerHTML = "140 characters remaining";
        //$("#button_block").slideUp("fast");

    });
}

function followingPage(userid, sessionid) {
    $('.page-content').empty();
    var followList = [];
    var followListUname = [];
    $.get('/connect/user/following', {
                userid : userid
            }, function(data) {
        var followObject = $.parseJSON(data.val);
        for (var i = 0; i < followObject.length; i++) {
            followList.push(followObject[i].userid);
            followListUname.push(followObject[i].uname);
        }
        for (var i = 0; i < followList.length; i++) {
            var obj = {};
            obj['followingid'] = followList[i];
            obj['buttonText'] = "unfollow";
            obj["sessionid"] = sessionid;
            obj["userid"] = userid;
            obj["uname"] = followListUname[i];
            showFollowing(obj);
        }
    });
}

function followersPage(userid, sessionid) {
    $('.page-content').empty();
    $.get('/connect/user/followers', {userid:userid}, function(data){
        var followerObject = $.parseJSON(data.val);
        //console.log(followerObject);
        for (var i = 0; i < followerObject.length; i++) {
            var obj = {};
            if(followerObject[i].pass == "follows"){
                obj["buttonText"] = "unfollow";
            }
            else{
             obj["buttonText"] = "follow";
            }
            obj["uname"] = followerObject[i].uname;
            obj['followerid'] = followerObject[i].userid;
            obj['sessionid'] = sessionid;
            obj['userid'] = userid;
            showFollowers(obj);
        }

    });
}
function doSearch() {
    var searchText = document.getElementsByClassName('search-query-box')[0].value;
    window.location = '/search?query=' + searchText;
}