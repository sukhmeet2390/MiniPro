package twitter.controllers;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import twitter.models.Tweet;
import twitter.models.UploadImage;
import twitter.models.User;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    SimpleJdbcTemplate jdbc;
    Utility util;
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;

    @Autowired
    public UserController(SimpleJdbcTemplate jdb, Utility uti, UserStore ust, TweetStore tst, FollowStore fst) {
        this.jdbc = jdb;
        this.followstore = fst;
        this.util = uti;
        this.userstore = ust;
        this.tweetstore = tst;
    }

    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    ModelAndView userregister(@RequestParam String username, @RequestParam String password, @RequestParam String useremail) {
        ModelAndView mv = new ModelAndView("index");
        User tempuser = new User();
        tempuser.uemail = useremail;
        tempuser.uname = username;
        tempuser.pass = util.doHash(password);
        tempuser.userid = util.genkey();
        userstore.registerUser(tempuser);
        return mv;


    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    ModelAndView userlogin(@RequestParam String useremail, @RequestParam String password, HttpSession session) {
        ModelAndView mv = new ModelAndView("index");
        User tempuser = new User();
        tempuser.uemail = useremail;
        tempuser.pass = util.doHash(password);
        Map<String, Object> ret = userstore.loginUser(tempuser);
        if ((Boolean) ret.get("login")) {
            Map<String, Object> loginfo = (Map<String, Object>) ret.get("user");
            session.setAttribute("userid", loginfo.get("userid"));
            session.setAttribute("username", loginfo.get("uname"));
            mv.setViewName("redirect:/user/feed");
        } else {
            mv.setViewName("redirect:/");
            mv.addObject("login", "failed");
        }
        return mv;
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    ModelAndView logoutUser(HttpSession session) {
        session.invalidate();
        ModelAndView mv = new ModelAndView("redirect:/");
        return mv;
    }

    @RequestMapping(value = "/feed")
    ModelAndView showFeed(HttpSession session) {
        ModelAndView mv = new ModelAndView("feed");
        mv.addObject("userid", (String) session.getAttribute("userid"));
        mv.addObject("username", (String) session.getAttribute("username"));
        return mv;
    }

    @RequestMapping(value = "/profile")
    ModelAndView showProfile(HttpSession session, @RequestParam String userid) {
        //System.out.println(userid);
        ModelAndView mv = new ModelAndView("/profile");
        User user = userstore.getProfile(userid);
        mv.addObject("profilename", user.uname);
        mv.addObject("userid",userid);
        mv.addObject("sessionid", (String) session.getAttribute("userid"));
        return mv;
    }

    @RequestMapping(value = "/editProfile")
    ModelAndView editProfile(HttpSession session,HttpServletRequest request) {
        String uid = (String) session.getAttribute("userid");
        ModelAndView mv = new ModelAndView("/edit_profile");
        User usr = userstore.getProfile(uid);
        mv.addObject("username", usr.uname);
        mv.addObject("useremail", usr.uemail);
        //System.out.print(usr.uname);
        String msg=(String)session.getAttribute("error");
        if(msg!=null){
            mv.addObject("error",msg);
            session.removeAttribute("error");
        }
        //mv.addObject("msg","success");
        return mv;
    }

    @RequestMapping(value = "/editProfile", method = RequestMethod.POST)
    ModelAndView modifyProfile(UploadImage img, HttpSession session,HttpServletRequest request,@RequestParam String uname, @RequestParam String uemail, @RequestParam String pass, @RequestParam String password, @RequestParam String confirmpassword) {
        ModelAndView mv = new ModelAndView("redirect:/user/editProfile");
        String uid = (String) session.getAttribute("userid");
        img.setName(uid);
        User user = new User();
        user.uname = uname;
        user.uemail = uemail;
        user.pass = util.doHash(pass);
        user.userid = uid;
        if ((Boolean) userstore.loginUser(user).get("login")) {
            if (password.equals(confirmpassword)&&!password.equals("")) {
                user.pass = util.doHash(password);
                userstore.editProfile(user);
            }
            else{
                userstore.editProfilewopass(user);
            }
            session.setAttribute("error","successful");
            util.StoreImage(img);
        }
        else{
                //System.out.print("wrong pass");
                //request.setAttribute("msg","wrong password");
                session.setAttribute("error","wrongpass");
        }
        return mv;
    }




    @RequestMapping(value = "/getfeed", method = RequestMethod.GET)
    @ResponseBody
    Hashtable<String, String> getFeed(@RequestParam Integer offset, @RequestParam Integer size, HttpSession session) {
        Hashtable<String, String> hs = new Hashtable<String, String>();
        Gson gson = new Gson();
        List<Tweet> ls = tweetstore.getMoreNewsFeed((String) session.getAttribute("userid"), offset, size);
        hs.put("val", gson.toJson(ls));
        return hs;

    }




    @RequestMapping(value = "/getstats")
    @ResponseBody
    Hashtable<String, Integer> getUserStats(@RequestParam String userid) {
        Hashtable<String, Integer> hs = new Hashtable<String, Integer>();
        hs.put("tweetcount", userstore.getUserTweetsNumber(userid));
        hs.put("followernum", userstore.getNumberFollowers(userid));
        hs.put("followingnum", userstore.getNumberFollowing(userid));
        return hs;
    }

}

