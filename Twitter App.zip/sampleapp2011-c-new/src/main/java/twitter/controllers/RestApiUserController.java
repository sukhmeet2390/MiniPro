package twitter.controllers;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import twitter.models.Tweet;
import twitter.models.User;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/restapi/user")
public class RestApiUserController {
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;
    Utility util;

    @Autowired
    public RestApiUserController(UserStore ust,Utility uti,TweetStore twt,FollowStore fst){
        this.userstore = ust;
        this.util = uti;
        this.tweetstore = twt;
        this.followstore=fst;
    }

    @RequestMapping(value = "/",method = RequestMethod.GET)
    @ResponseBody
    List<User> RestgetUsers(){
        return userstore.getUsers();
    }


    @RequestMapping(value = "/",method = RequestMethod.POST)
    @ResponseStatus( HttpStatus.CREATED )
    @ResponseBody
    User RestaddUser(HttpServletRequest request){
        Gson gson = new Gson();
        User user = gson.fromJson((String)request.getAttribute("json"),User.class);
        user.userid = util.genkey();
        userstore.registerUser(user);
        return user;
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.GET)
    @ResponseBody
    User RestgetUserbyID(@PathVariable("uid") String uid){
        return userstore.getProfile(uid);
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void RestDeleteUserbyID(@PathVariable("uid") String uid){
        userstore.deleteUser(uid);
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.OK)
    void RestUpdateUserbyID(@PathVariable("uid") String uid , HttpServletRequest request){
        Gson gson = new Gson();
        User user = gson.fromJson((String)request.getAttribute("json"),User.class);
        User newuser = new User();
        newuser.uname = user.uname;
        newuser.pass = util.doHash(user.pass);
        newuser.userid = uid;
        //user.userid=uid;
        userstore.editProfile(newuser);
    }

    @RequestMapping(value = "/{uid}/feed/{size}")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    List<Tweet> GetFeed(@PathVariable("uid") String uid,@PathVariable("size")Integer size){
        return tweetstore.getMoreNewsFeed(uid,99999,size);
    }


}
