function buildProfilePage(userid, sessionid, profilename) {
    showSideBarStats(userid, profilename, sessionid);
    profilePage(userid, sessionid, profilename);
    loadMoreTweetsEvent(userid);
    if (userid != sessionid) {
        $('#hidden-button').append("<button id ='profile-follow-unfollow-button' class='btn hidden-button'></button>");
        $.get('/connect/user/followers', {
                    userid : sessionid
                }, function(data) {
            var followObject = ($.parseJSON(data.val))[0];
            var text = "";
            if(followObject["pass"] =="follows") text = "unfollow";
            else text = "follow";

            $('#profile-follow-unfollow-button').html(text);
            $('#profile-follow-unfollow-button').bind("click",function() {
                profileHiddenButton(text, userid);
            });
        });
    }
}

function profileHiddenButton(text, userid) {
    if (text == 'follow') {
        $.post('/connect/user/follow', {userid:userid}, function() {
            document.getElementById('profile-follow-unfollow-button').innerHTML = "unfollow";
        });
    }
    else if (text == 'unfollow') {
        $.post('/connect/user/unfollow', {userid:userid}, function() {
            document.getElementById('profile-follow-unfollow-button').innerHTML = "follow";
        });
    }
}

function profilePage(userid, sessionid) {
    $('.page-content').empty();
    $.get('/tweet/user?offset=999999&size=10', {
                userid : userid
            }, function(data) {
        var obj = $.parseJSON(data.val);
        for (var i = 0; i < obj.length; i++) {
            obj[i]["displayTime"] = correctTime(obj[i].time);
            printProfileFeed(obj[i]);
        }
        var LoadMoreTweets = '<div id="load-more-tweets-container"><div id="load-more-tweets" class="load-more">Load more tweets</div></div>';
        loadMoreTweetsEvent(userid);
        $('.page-content').append(LoadMoreTweets);
    });

}

function loadMoreTweetsEvent(userid) {
    $('#load-more-tweets').live("click", function() {
        var arr = $('.tweet-id-hidden');
        offsetFeed = arr[arr.length-1].value;
        $.get('/tweet/user?offset='+offsetFeed+'&size=5',{userid:userid},function(data) {
            var obj = $.parseJSON(data.val);
            for (var i = 0; i < obj.length; i++) {
                obj[i]["displayTime"] = correctTime(obj[i].time);
                loadMoreTweets(obj[i]);
            }
            var arr = $('.tweet-id-hidden');
            offsetFeed = arr[arr.length-1].value;
        });
    });
}