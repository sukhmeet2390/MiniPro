use twit;

create table if not exists users(
	uname varchar(50) not null,
	uemail varchar(255) not null,
	upass varchar(255)  not null,
	userid varchar(255) ,
	UNIQUE KEY (uemail),
	PRIMARY KEY (userid)
);


create table if not exists tweets(
	tweetid int(64)  not null auto_increment,
	userid varchar(255),
	content varchar(140) not null,
	time datetime  not null,
	PRIMARY KEY (tweetid),
	FOREIGN KEY (userid) references users(userid)
);


create table if not exists followers(
	uidA varchar(255),
	uidB varchar(255),
	time_unfollow datetime not null default '9999-01-01 01-01-01',
	PRIMARY KEY (uidA,uidB),
	FOREIGN KEY (uidA) references users(userid),
	FOREIGN KEY (uidB) references users(userid)	
);


