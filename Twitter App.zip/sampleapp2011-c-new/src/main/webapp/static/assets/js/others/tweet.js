function refreshTweet(number) {
    $.get('/tweet/countnew', {
                time:number
            }, function(data) {
        if (data > 0) {
            appendNewTweets(number);
        }
    });
}

function appendNewTweets(number) {
    oldTweetTime = $('.tweet-container').children()[0].children[3].value;
    $.get('/tweet/getnew', {time:oldTweetTime}, function(data) {
        for (var i = 0; i < data.length; i++) {
            data[i]["userid"] = data[i].user;
            data[i]["displayTime"] = correctTime(data[i].time);
            var html = $(new EJS({url:'/static/ejs/addTweet.ejs'}).render(data[i]));
            $('.feed-content').prepend(html);

        }
        oldTweetTime = data[0].time;
    });

}