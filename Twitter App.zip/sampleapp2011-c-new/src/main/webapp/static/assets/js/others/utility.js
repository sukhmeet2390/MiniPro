function updateCountdown() {
    // 140 is the max message length
    var remaining = 140 - jQuery('#edit-name').val().length;
    jQuery('.countdown').text(remaining + ' characters remaining.');
    if (remaining < 0) {
        $('#tweet-button').css("visibility", "hidden");
        jQuery('.countdown').text('-' + extra + ' characters.');

    }
    else $('#tweet-button').css("visibility", "visible");
}

function showSideBarStats(userid, username, sessionid) {
    $('#side-bar-container').empty();
    $.get('/user/getstats', {
                userid:userid
            }, function(data) {
        data["username"] = username;
        data["userid"] = userid;
        data["sessionid"] = sessionid;
        var tmpl = $(new EJS({url:'/static/ejs/sidebar.ejs'}).render(data));
        $('#side-bar-container').append(tmpl);
    });
}

function markActive(div, userid, sessionid) {
    $('.active').removeClass('active');
    var link = $(div).attr("title");
    if (link == "profile") {
        $('#profile-link').addClass('active');
        profilePage(userid, sessionid);
    }
    if (link == "followers") {
        $('#followers-link').addClass('active');
        followersPage(userid, sessionid);
    }
    if (link == "following") {
        $('#following-link').addClass('active');
        followingPage(userid, sessionid);
    }
    if (link == "allusers") {
        $('#allusers').addClass('active');
        allUsersPage();
    }
    return;
}


function updateButton(mixedString) {
    var text = mixedString.split(',')[0];
    var userid = mixedString.split(',')[1];
    if (text == 'follow') {
        $.post('/connect/user/follow', {userid:userid}, function() {
            document.getElementById('follow-unfollow-button-' + userid).innerHTML = "unfollow";
        });
    }
    else if (text == 'unfollow') {
        $.post('/connect/user/unfollow', {userid:userid}, function() {
            document.getElementById('follow-unfollow-button-' + userid).innerHTML = "follow";
        });
    }
}

function focusEditButton() {
    $(function() {
        $("#edit-name").focus(function() {
            $('.form-tweet').css("height", "75px");
            //$("#button_block").slideDown("fast");
            return false;
        });
    });
    $(function() {
        $("#edit-name").blur(function() {
            $('.form-tweet').css("height", "38px");
            //$("#button_block").slideUp("fast");
            return false;
        });
    });

}


function popupShow() {
    $('#registerHere input').hover(function() {
        $(this).popover('show')
    });
}
function validate() {
    $("#registerHere").validate({
                rules : {
                    username : "required",
                    useremail : {
                        required : true,
                        email : true
                    },
                    password : {
                        required : true,
                        minlength : 6
                    },
                    confirmpassword : {
                        required : true,
                        equalTo : "#password"
                    },
                },
                messages : {
                    user_name : "Enter your first and last name",
                    user_email : {
                        required : "Enter your email address",
                        email : "Enter valid email address"
                    },
                    password : {
                        required : "Enter your password",
                        minlength : "Password must be minimum 6 characters"
                    },
                    confirmpassword : {
                        required : "Enter confirm password",
                        equalTo : "Password and Confirm Password must match"
                    },
                },
                errorClass : "help-inline",
                errorElement : "span",
                highlight : function(element, errorClass, validClass) {
                    $(element).parents('.control-group').addClass('error');
                },
                unhighlight : function(element, errorClass, validClass) {
                    $(element).parents('.control-group').removeClass('error');
                    $(element).parents('.control-group').addClass('success');
                }
            });
}
function tabClick() {
    $(".tab").click(function() {
        var X = $(this).attr('id');

        if (X == 'signup') {
            $("#login").removeClass('select');
            $("#signup").addClass('select');
            $("#loginbox").slideUp();
            $("#signupbox").slideDown();
        } else {
            $("#signup").removeClass('select');
            $("#login").addClass('select');
            $("#signupbox").slideUp();
            $("#loginbox").slideDown();
        }

    });
}
offsetFeed = 0;
offsetTweets = 0;
sizeFeed = 5;
sizeTweets = 2;

function editFormValidate() {
    $("#editHere").validate({
                rules : {
                    username : "required",
                    password : {
                        minlength : 6
                    },
                    pass:{
                        required: true
                    },
                    confirmpassword : {
                        equalTo : "#password"
                    },

                },
                messages : {
                    user_name : "Enter your first and last name",
                    password : {
                        required : "Enter your password",
                        minlength : "Password must be minimum 6 characters"
                    },
                    confirmpassword : {
                        required : "Enter confirm password",
                        equalTo : "Password and Confirm Password must match"
                    },
                },
                errorClass : "help-inline",
                errorElement : "span",
                highlight : function(element, errorClass, validClass) {
                    $(element).parents('.control-group').addClass('error');
                },
                unhighlight : function(element, errorClass, validClass) {
                    $(element).parents('.control-group').removeClass('error');
                    $(element).parents('.control-group').addClass('success');
                }
            });
}


function correctTime(time) {
    var currentTime = new Date();
    var gmtTime = new Date(time);
    var diffInMilliSeconds = currentTime - gmtTime;
    var showTime = CorrectTimeforMilliSeconds(diffInMilliSeconds);
    return showTime;

}

function CorrectTimeforMilliSeconds(time) {
    var seconds = Math.round(time / 1000);
    if (seconds < 60)  return "Just now";
    var ret = "";
    var hours = 0;
    var minutes = 0;
    if (seconds > 3600) {
        hours = parseInt(seconds / 3600);
        minutes = parseInt((seconds - hours * 3600) / 60);
        if (hours >= 24) {
            var days = parseInt(hours / 24);
            hours = parseInt(hours - days * 24);
            var plural = "";
            if (days > 1) plural = "s";
            ret += days + " day" + plural + " ago";
            return ret;
        }
        var plural = "";
        if (hours > 1) plural = "s";
        ret += hours + " hour" + plural + " " + minutes + " minutes ago";
    } else {
        minutes = parseInt((seconds) / 60);
        var plural = "";
        if (minutes > 1) plural = "s"
        ret = minutes + " minute" + plural + " ago "
    }
    return ret;

}

function readImage(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#user-img').attr('src', e.target.result).width(150).height(200);
        }
        reader.readAsDataURL(input.files[0]);
    }
}