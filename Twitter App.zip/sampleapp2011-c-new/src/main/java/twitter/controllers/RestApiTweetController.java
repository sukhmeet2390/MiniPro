package twitter.controllers;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import twitter.models.Tweet;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/restapi/tweets/user")
public class RestApiTweetController {
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;
    Utility util;

    @Autowired
    public RestApiTweetController(UserStore ust,Utility uti,TweetStore twt,FollowStore fst){
        this.userstore = ust;
        this.util = uti;
        this.tweetstore = twt;
        this.followstore=fst;
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.GET)
    @ResponseBody
    List<Tweet> RestGetUserTweets(@PathVariable("uid") String uid){
        return userstore.getUserTweets(uid,9999,1000);
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.POST)
    @ResponseBody
    Tweet RestUserTweet(@PathVariable("uid") String uid ,HttpServletRequest request){
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        Gson gson = new Gson();
        Tweet tweet =  gson.fromJson((String)request.getAttribute("json"),Tweet.class);
        tweet.time=dateFormat.format(date);
        tweet.user = uid;
        tweet.id = String.valueOf(tweetstore.tweet(tweet));
        return tweet;
    }
}
