function showAllUsers(data) {
    var tmpl = $(new EJS({url:'/static/ejs/showAllUsers.ejs'}).render(data));
    $('.page-content').append(tmpl);
}

function showFollowing(data) {
    var tmpl = $(new EJS({url:'/static/ejs/followTemplate.ejs'}).render(data));
    $('.page-content').append(tmpl);
    if (data.sessionid.toString() != data.userid.toString()) {
        $('#follow-unfollow-button-container').empty();
    }
}

function printTweet(data) {
    var tmpl = $(new EJS({url:'/static/ejs/printTweet.ejs'}).render(data));
    $('.feed-content').append(tmpl);
}

function loadMoreTweets(data) {
    var tmpl = $(new EJS({url:'/static/ejs/printTweet.ejs'}).render(data));
    $(tmpl).insertBefore('#load-more-tweets-container');
}

function printProfileFeed(data) {
    var tmpl = $(new EJS({url:'/static/ejs/printTweet.ejs'}).render(data));
    $('.page-content').append(tmpl);
}

function printSearchUser(data) {
    var tmpl = $(new EJS({url:'/static/ejs/printSearchUser.ejs'}).render(data));
    $('#search-user-content').prepend(tmpl);
}
function printSearchTweet(data) {
    var tmpl = $(new EJS({url:'/static/ejs/printSearchTweet.ejs'}).render(data));
    $('#search-tweet-content').prepend(tmpl);
}

function showFollowers(data) {
    var tmpl = $(new EJS({
                url:'/static/ejs/followingTemplate.ejs'}).render(data));
    $('.page-content').append(tmpl);
    if (data.sessionid != data.userid) {
        $('#follow-unfollow-button-container').empty();
    }
}

function addNavbar(){
    var tmpl = $(new EJS({url:'/static/ejs/navbar.ejs'}).render());
    $('#navbar-content').append(tmpl);
}