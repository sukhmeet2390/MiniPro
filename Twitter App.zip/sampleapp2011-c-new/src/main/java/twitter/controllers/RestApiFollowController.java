package twitter.controllers;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import twitter.models.User;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/restapi/follows/user")
public class RestApiFollowController {
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;
    Utility util;

    @Autowired
    public RestApiFollowController(UserStore ust,Utility uti,TweetStore twt,FollowStore fst){
        this.userstore = ust;
        this.util = uti;
        this.tweetstore = twt;
        this.followstore=fst;
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.GET)
    @ResponseBody
    List<User> RestGetFollowing(@PathVariable("uid") String uid){
        return followstore.getFollows(uid);
    }

    @RequestMapping(value = "/{uid}",method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    void RestFollow(@PathVariable("uid")String uid , HttpServletRequest request){
        Gson gson = new Gson();
        User user = gson.fromJson((String)request.getAttribute("json"),User.class);
        followstore.Follow(uid,user.userid);
    }

    @RequestMapping(value = "/{uid}/user/{uidB}",method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    void RestUnfollow(@PathVariable("uid")String uid , @PathVariable("uidB")String uidB){
        followstore.unFollow(uid,uidB);
    }
}
