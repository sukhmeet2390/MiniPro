package twitter.models;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class User {
    public String uemail;
    public String pass;
    public String userid;
    public String uname;

    public void setUname(String uname) {
        this.uname = uname;
    }

    public void setUemail(String uemail) {
        this.uemail = uemail;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }


    public String getUname() {
        return uname;
    }

    public String getUemail() {
        return uemail;
    }

    public String getPass() {
        return pass;
    }

    public String getUserid() {
        return userid;
    }


    public static final RowMapper<User> rowMapper = new RowMapper<User>() {
        @Override
        public User mapRow(ResultSet resultSet, int i) throws SQLException {
            return new User(resultSet);
        }
    };

    public User() {
    }

    public User(ResultSet rs) {
        try {
            this.userid = rs.getString("userid");

            this.uname = rs.getString("uname");
            this.uemail = rs.getString("uemail");

        } catch (Exception exc) {
        }
    }
}
