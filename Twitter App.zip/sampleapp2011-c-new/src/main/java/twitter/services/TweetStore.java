package twitter.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Service;
import twitter.models.Tweet;

import java.util.List;

@Service
public class TweetStore {
    SimpleJdbcTemplate jdbc;

    @Autowired
    public TweetStore(SimpleJdbcTemplate jdb) {
        this.jdbc = jdb;
    }

    public List<Tweet> getNewsFeed(String userid) {
        return jdbc.query("(select tweets.tweetid as tweetid,tweets.userid as userid , tweets.time as time," +
                "tweets.content as content from followers,tweets where (followers.uidA=? and " +
                "followers.uidB = tweets.userid and tweets.time <= followers.time_unfollow)" +
                " or tweets.userid=? )as rs", Tweet.rowMapper, userid, userid);

    }

    public List<Tweet> getMoreNewsFeed(String userid, int offset, int size) {
        return jdbc.query("select  rs.tweetid as tweetid,rs.userid as userid,rs.content as content,rs.time as time,users.uname as username " +
                "from users,(select distinct tweets.tweetid as tweetid,tweets.userid as userid , tweets.time as time," +
                "tweets.content as content from followers,tweets where ((followers.uidA=? and " +
                "followers.uidB = tweets.userid and tweets.time <= followers.time_unfollow)" +
                " or tweets.userid=?) and tweets.tweetid < ? order by tweets.time desc limit ?) as rs where users.userid = rs.userid", Tweet.rowMapper, userid, userid, offset, size);

    }

    public int getcountnewtweets(String uid, String time) {
        return jdbc.queryForInt("select count(tweets.tweetid) from followers,tweets where followers.uidA=? and followers.uidB=tweets.userid and tweets.time>?", uid, time);
    }

    public List<Tweet> getnewtweets(String uid, String time) {
        return jdbc.query("select  rs.tweetid as tweetid,rs.userid as userid,rs.content as content,rs.time as time,users.uname as username" +
                "                from users,(select distinct tweets.tweetid as tweetid,tweets.userid as userid , tweets.time as time," +
                "tweets.content as content,followers.uidA as username from followers,tweets where " +
                "followers.uidA=? and followers.uidB=tweets.userid and tweets.time>? order by tweets.time desc)as rs where users.userid = rs.userid", Tweet.rowMapper, uid, time);
    }

    public int tweet(Tweet tw) {
        jdbc.update("insert into tweets (userid,content,time) values(?,?,?)", tw.user, tw.content, tw.time);
        int id = jdbc.queryForInt("SELECT LAST_INSERT_ID()");
        return id;
    }

    public List<Tweet> searchTweet(String query) {
        return jdbc.query("select * from tweets where content like ?", Tweet.rowMapper,"%"+query+"%");
    }


    public int retweet(String uid,Integer tweetid,String time){
        return jdbc.update("insert into retweets (userid,tweetid,time) values(?,?,?)",uid,tweetid,time);
    }

}
