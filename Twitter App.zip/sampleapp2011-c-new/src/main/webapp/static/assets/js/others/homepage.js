function buildHomePage(userid, username) {
    showSideBarStats(userid, username, userid);
    homepageInitialFeed();
}

function loadMoreFeedEvent() {
    $('#load-more-feed').live("click", function() {
        var arr = $('.tweet-id-hidden');
        offsetFeed = arr[arr.length - 1].value;

        $.get('/user/getfeed?offset=' + offsetFeed + '&size=' + sizeFeed, function(data) {
            var obj = $.parseJSON(data.val);
            for (var i = 0; i < obj.length; i++) {
                obj[i]["displayTime"] = correctTime(obj[i].time);
                printTweet(obj[i]);
            }
        });
    });
}

function homepageInitialFeed() {
    $.get('/user/getfeed?offset=99999' + '&size=10', function(data) {
        var obj = $.parseJSON(data.val);
        for (var i = 0; i < obj.length; i++) {
            obj[i]["displayTime"] = correctTime(obj[i].time);
            printTweet(obj[i]);
        }
    });
    var arr = $('.tweet-id-hidden');
    offsetFeed = arr[arr.length - 1].value;
}

function buildFeedPage(userid, username) {
    focusEditButton();
    loadMoreFeedEvent();
    updateCountdown();
    $('#edit-name').change(updateCountdown);
    $('#edit-name').keyup(updateCountdown);
    buildHomePage(userid, username);
    setInterval(function() {
        oldTweetTime = $('.tweet-container').children()[0].children[3].value;
        //console.log(oldTweetTime);
        refreshTweet(oldTweetTime);
    }, 5000);
}