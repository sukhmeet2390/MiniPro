package twitter.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import twitter.services.FollowStore;
import twitter.services.TweetStore;
import twitter.services.UserStore;
import twitter.services.Utility;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("restapi")
public class RestApiController {
    UserStore userstore;
    TweetStore tweetstore;
    FollowStore followstore;
    Utility util;
    @Autowired
    public RestApiController(UserStore ust,Utility uti,TweetStore twt,FollowStore fst){
        this.userstore = ust;
        this.util = uti;
        this.tweetstore = twt;
        this.followstore=fst;
    }

    @RequestMapping(value = "/followers/user/{uid}",method = RequestMethod.GET)
    @ResponseBody
    List<Map<String,Object>> RestGetFollowers(@PathVariable("uid") String uid){
        return followstore.getFollowers(uid);
    }



    @RequestMapping(value = "test")
    @ResponseBody
    Hashtable<String,String> test(@RequestHeader String hash){
        Hashtable<String,String> hs = new Hashtable<String, String>();
        hs.put("val",hash);

        return hs;
    }

}
