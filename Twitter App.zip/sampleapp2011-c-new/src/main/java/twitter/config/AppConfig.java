package twitter.config;

/**
 * Created with IntelliJ IDEA.
 * User: vinayak
 * Date: 2/7/12
 * Time: 1:56 PM
 * To change this template use File | Settings | File Templates.
 */
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

@Configuration
public class AppConfig {
    @Bean
    public SimpleJdbcTemplate simpleJdbcTemplate() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setUrl("jdbc:mysql://localhost:3306/twit");
        dataSource.setDriverClassName("com.mysql.jdbc.Driver");
        dataSource.setUsername("root");
        dataSource.setPassword("");
        SimpleJdbcTemplate db = new SimpleJdbcTemplate(dataSource);

        return db;
    }
    @Bean
    public ThreadLocal<String> userID() {
        return new ThreadLocal<String>();
    }
}
