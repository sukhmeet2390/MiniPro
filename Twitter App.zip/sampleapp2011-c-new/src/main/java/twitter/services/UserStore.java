package twitter.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Service;
import twitter.models.Tweet;
import twitter.models.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserStore {
    private final ThreadLocal<String> userid;
    SimpleJdbcTemplate jdbc;

    @Autowired
    public UserStore(@Qualifier("userID") ThreadLocal<String> userId, SimpleJdbcTemplate jdb) {
        this.jdbc = jdb;
        this.userid = userId;
    }

    public boolean registerUser(User temp) {
        jdbc.update("insert into users (userid,uname,uemail,upass) values(?,?,?,?)", temp.userid, temp.uname, temp.uemail, temp.pass);
        return true;

    }

    public Map<String, Object> loginUser(User temp) {
        Map<String, Object> usermap;
        Map<String, Object> ret = new HashMap<String, Object>();
        try {
            usermap = jdbc.queryForMap("select * from users where uemail=? and upass=?", temp.uemail, temp.pass);
            ret.put("login", true);
            ret.put("user", usermap);
        } catch (Exception ex) {
            ret.put("login", false);

        }
        return ret;
    }

    public List<User> getUsers() {
        return jdbc.query("select * from users ", User.rowMapper);
    }


    public User getProfile(String userid) {
        return jdbc.queryForObject("select * from users where userid=?", User.rowMapper, userid);
    }

    public User editProfile(User user) {
        jdbc.update("update users set uname=?,upass=? where userid=?", user.uname, user.pass, user.userid);
        return user;
    }

    public List<Tweet> getUserTweets(String userid, int offset, int size) {
        return jdbc.query("select *,(select uname from users where userid=?) as username from tweets where userid=? and tweetid < ? order by tweets.time desc limit ?", Tweet.rowMapper, userid, userid, offset, size);
    }


    public int getUserTweetsNumber(String userid) {
        return jdbc.queryForInt("select count(tweetid) from tweets where userid=?", userid);
    }

    public int getNumberFollowers(String userid) {
        return jdbc.queryForInt("select count(*) from followers where uidB=? and time_unfollow='9999-01-01 01:01:01'", userid);
    }

    public int getNumberFollowing(String userid) {
        return jdbc.queryForInt("select count(*) from followers where uidA=? and time_unfollow='9999-01-01 01:01:01'", userid);
    }

    public void deleteUser(String uid) {
        jdbc.update("delete from users where userid=?", uid);
    }

    public String getsecretHash(String userid) {
        return jdbc.queryForObject("select upass from users where userid=?", String.class, userid);
    }

    public List<User> getAllUsers() {
        return jdbc.query("select * from users", User.rowMapper);
    }

    public List<User> SearchUser(String query) {
        return jdbc.query("select * from users where uname like ?", User.rowMapper, "%" + query + "%");
    }

    public User editProfilewopass(User user) {
        jdbc.update("update users set uname=? where userid=?", user.uname, user.userid);
        return user;
    }
}

