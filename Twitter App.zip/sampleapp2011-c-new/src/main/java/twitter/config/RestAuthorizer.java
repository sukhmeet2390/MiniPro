package twitter.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import twitter.services.UserStore;
import twitter.services.Utility;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;

/**
 * Created with IntelliJ IDEA.
 * User: vinayak
 * Date: 30/7/12
 * Time: 6:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class RestAuthorizer extends HandlerInterceptorAdapter {
    UserStore userstore;
    Utility util;

    @Autowired
    public RestAuthorizer(UserStore ust,Utility uti){
        this.userstore=ust;
        this.util=uti;
    }

    boolean Authorize(String pubkey,String hash,String data){
        String prikey;
        try{
            prikey = userstore.getsecretHash(pubkey);
        }
        catch (Exception exc){return false;}
        String hashcandidate = data+prikey;
        String server_hash = util.SHAhash(hashcandidate);
        return server_hash.equals(hash);
    }

    String getRequestContent(HttpServletRequest request)throws Exception{
        int length = request.getContentLength();
        char [] bt = new char[length];
        byte [] b  = new byte[length];
        BufferedReader read = new BufferedReader(request.getReader());

        //request.getInputStream().readLine(b,0,length);
       // read.mark(length);
        read.read(bt);
       // read.reset();
        //read.close();
       return new String(bt,0,length);

    }


    @Override
    public boolean preHandle(HttpServletRequest request ,HttpServletResponse response, Object handler)throws Exception{
        String method = request.getMethod();
        String data="";
        if(method=="POST" || method=="PUT" || method=="DELETE"){
            String privatekey = request.getHeader("hash");
            if(!method.equals("DELETE"))
                data=getRequestContent(request);
            String publickey = request.getRequestURI().split("user/")[1];
            if(publickey.contains("/"))
                publickey = publickey.split("/")[0];
            //data=getRequestContent(request);
            if(Authorize(publickey, privatekey, data)) {
                request.setAttribute("json",data);
                return true;
            }
            else{
                response.sendError(404,"Permission denied");
                return false;
            }
        }

        return true;
    }
}
