package twitter.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Service;
import twitter.models.User;

import java.util.List;
import java.util.Map;

@Service
public class FollowStore {
    SimpleJdbcTemplate jdbc;
    @Autowired
    public FollowStore(SimpleJdbcTemplate jdb){
        this.jdbc = jdb;
    }

    public List<Map<String,Object>> getFollowers(String userid){
        //return jdbc.query("select users.uname as uname,rs.userid as userid from users,(select uidA as userid from followers where followers.uidB=? and followers.time_unfollow='9999-01-01 01:01:01') as rs where users.userid=rs.userid",User.rowMapper,userid);
        return jdbc.queryForList("(select if(rs.uidA in (select uidB from followers where uidA=? and time_unfollow='9999-01-01 01:01:01'),'follows','unfollows') as pass, users.uname as uname, rs.uidA as userid from users,followers as rs where users.userid=rs.uidA and rs.uidB=? and  rs.time_unfollow='9999-01-01 01:01:01')", userid, userid);
    }

    public List<User> getFollows(String userid){
        return jdbc.query("select users.userid as userid,users.uname as uname from users,followers where followers.uidA=? and followers.time_unfollow='9999-01-01 01:01:01' and users.userid=followers.uidB",User.rowMapper,userid);
    }

    public boolean Follow(String uidA, String uidB){
        try{
            jdbc.queryForMap("select * from followers where uidA=? and uidB=?",uidA,uidB);
            jdbc.update("update followers set time_unfollow='9999-01-01 01-01-01' where uidA=? and uidB=?",uidA,uidB);
        }
        catch (Exception exc){
            jdbc.update("insert into followers (uidA,uidB) values (?,?)",uidA,uidB);
        }
        return true;
    }

    public boolean unFollow(String uidA,String uidB){
        jdbc.update("update followers set time_unfollow=now() where uidA=? and uidB=?",uidA,uidB);
        return true;
    }


}
