function allUsersPage() {
    $('.page-content').empty();
    $.get('/getallusers', function(data) {
        for (var i = 0; i < data.length; i++) {
            showAllUsers(data[i]);
        }

    });
}

function loginPage() {
    popupShow();
    validate();
    tabClick();
}
function buildEditPage() {
    editFormValidate();
    addNavbar();
}
function retweet(id, user, time) {
}